//
//  NITextField.h
//  CustomTextField
//
//  Created by Amit Bobade on 02/01/13.
//  Copyright (c) 2013 Amit Bobade. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NITextFieldDelegate;

typedef enum  {
   NITextFieldTypeNone = 0,
   NITextFieldTypePicker = 1 ,
   NITextFieldTypeDatePicker = 2
} NITextFieldType;


@interface NITextField : UITextField <UIPickerViewDelegate,UIPickerViewDataSource>
{
    
@private;
    UIPopoverController * popOverController;
}
-(id)initWithType:(NITextFieldType)type_;
@property(nonatomic,strong) NSDate * date;
@property(nonatomic) NITextFieldType type;
@property(nonatomic,strong) NSArray * items;
@property(nonatomic) UIDatePickerMode datePickerMode;
@property(nonatomic,strong) NSDateFormatter * dateFormatter;
@property(nonatomic,assign) id<NITextFieldDelegate> niDelegate;
@end

@protocol NITextFieldDelegate <NSObject>

-(void)next:(NITextField*)textField;
-(void)previous:(NITextField*)textField;

@end